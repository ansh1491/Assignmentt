const fs = require('fs');
const path = require('path');
const archiver = require('archiver');


function zipFolder(sourceDir, outPath) {
   
    const output = fs.createWriteStream(outPath);
    const archive = archiver('zip', {
        zlib: { level: 9 } 
    });

    output.on('close', () => {
        console.log(`Archive created successfully: ${archive.pointer()} total bytes.`);
    });

    archive.on('error', (err) => {
        throw err;
    });

   
    archive.pipe(output);

    
    archive.directory(sourceDir, false);

    
    archive.finalize();
}

// Usage
const folderToZip = path.join(__dirname, 'folder-to-zip'); // Change this to your folder
const zipFilePath = path.join(__dirname, 'output.zip'); // Change this to your desired zip file name

zipFolder(folderToZip, zipFilePath);
