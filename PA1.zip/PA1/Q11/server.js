// server.js
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Route to get live cricket scores
app.get('/api/live-scores', async (req, res) => {
    try {
        // Replace the URL with your live cricket scores API
        const response = await axios.get('https://cricapi.com/api/cricket?apikey=YOUR_API_KEY'); // Use a valid API key

        // Send the scores to the client
        res.json(response.data);
    } catch (error) {
        console.error('Error fetching live scores:', error.message);
        res.status(500).send('Error fetching live scores');
    }
});

// Root route to serve the index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
