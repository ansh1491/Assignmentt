// chatbot.js

class ChatBot {
    constructor() {
      this.responses = {
        'hello how are you': 'im fine',
        'what is your name': 'arjun',
        'who are you': 'im a bot'
      };
    }
  
    getResponse(userInput) {
      const input = userInput.toLowerCase();
      if (this.responses[input]) {
        return this.responses[input];
      } else {
        return "I'm sorry, I don't understand your question. Please ask something related to web development.";
      }
    }
  }
  
  module.exports = ChatBot;
  